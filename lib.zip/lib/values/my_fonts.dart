class MyFonts {
  @deprecated
  static const coolvetica = 'coolvetica';
  static const inter = 'inter';

  MyFonts._();
}