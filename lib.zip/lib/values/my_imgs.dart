class MyImgs {

  static const String logout = "assets/icons/logout.png";
  static const String image1 = "assets/images/image1.jpg";
  static const String image2 = "assets/images/image2.jpg";
  static const String image3 = "assets/images/image3.jpg";
  static const String image4 = "assets/images/image4.jpg";
  static const String image5 = "assets/images/image5.jpg";
  static const String imageIcon1 = "assets/images/imageIcon1.jpeg";
  static const String imageIcon2 = "assets/images/imageIcon2.png";

   static const String logo1 = "assets/images/logo1.png";

  MyImgs._();
}
