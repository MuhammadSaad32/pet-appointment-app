// class Strings {
//   static const String codeIsAuto = "Your Code is Auto Detect";
//   static const String phoneIsAlready =
//       "Phone number already exist Please use another number";
//   static const String phoneVerification = 'Phone Verification Code.';
//   static const String oPtCodeHere = 'Enter your Otp Code here';
//   static const String didntreceiveOTP = 'Didn\'t Received OTP? ';
//   static const String optVerify = 'Successfully OTP Verified.';
//   static const String invalidCode =
//       "Invalid Code Please Check Message and Enter Code Again";
//   static const String nextr = "ReSend";
//   static const String no = "No";
//   static const String yes = "Yes";
//   static const String failedToVerify = " Failed to Verify Phone Number:";
//   static const String entercode = "Enter Code";
//   static const String phoneVerificationFailed =
//       "Phone number verification failed. Message:";
//
//   static const String verifyNumber = "Verify Number :";
//   static const String tryAgain = 'Try Again';
//   static const String noInternetConnection = 'No Internet Connection';
//   static const String mgsLocation = 'Allow Location Permission';
//   static const String sContinue = 'Continue';
//   static const String permissionRequired = 'Permission Required';
//   static const String permissionText =
//       'For the best experience, Tim needs to use your current location to find closest provider for you. Do you want to share your location?';
//
//   static const String searchAddress = "Search Address";
//   static const String addTitle = "Address title";
//   static const String building = "Building/Apt";
//   static const String city = "City";
//   static const String state = "State";
//   static const String zip = "Zip code";
//   static const String address = "Abc Street, Abc city, Abc state";
//   static const String phoneFormat = "xxx xxx xxx";
//   static const String submit = "Submit";
//
// // app title
//   // App Strings
//   static const String firstName = "First Name";
//   static const String lastName = "Last Name";
//   static const String email = "Email";
//   static const String phone = "Phone No";
//   static const String pwd = "Password";
//   static const String confirmPwd = "Confirm Password";
//   static const String company = "Company";
//   static const String individual = "Individual";
//   static const String terms =
//       "By pressing “Submit” you agree to  our Terms & Condition";
//
//   static String resendOTP = "Resend OTP";
//
//   static const String emptyOTP = "Please Enter OTP code.";
//
//   static const String profile = "Profile";
//   static const String provider = "Become a Provider";
// }
